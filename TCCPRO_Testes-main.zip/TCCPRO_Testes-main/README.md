# Projeto TCCPRO (repositório para testes)

Esse projeto é sobre um site que fará formatações ABNT para otimizar o tempo dos professores/alunos ao corrigir, e escrever, seus trabalhos.

Funcionará com as linguagens HTML, CSS, Javascript, JAVA e SQL.

## A base do projeto será em JSP, a primeiro momento sem intenções de mudanças nas linguagens

> O projeto não é pessoal, é uma ideia de um associado da empresa!
> Nenhuma imagem de faculdades/instituições será usado.

> Desenvolvedores: [Pedro](https://github.com/pigasuaise) e [Nicolas A.](https://github.com/NickNorman2569) 
